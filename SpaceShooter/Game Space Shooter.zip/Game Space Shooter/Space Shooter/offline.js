﻿{
	"version": 1497203774,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/pesawat-sheet0.png",
		"images/meteor-sheet0.png",
		"images/peluru-sheet0.png",
		"images/ledakanmeteor.png",
		"images/ledakanpesawat.png",
		"images/bgscore-sheet0.png",
		"images/sprite-sheet0.png",
		"images/background-sheet0.png",
		"media/sounddestroy.ogg",
		"media/soundpeluru.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}